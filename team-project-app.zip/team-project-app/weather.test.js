/**
 * @jest-environment jsdom
 */
 
 
const sideTest = require('./weather.js')

test('sidebar width is ok',() =>{
    expect(sideTest.openNav('mySidebar')).toBe('250px');
})

