/**
 * @jest-environment jsdom
 */
 
 
 const locTest = require('./index.js')

 test('location on map is ok',() =>{
     expect(locTest.initMap(uluru)).toBe(53.3498, -6.2603);
 })